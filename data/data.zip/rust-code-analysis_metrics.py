#!/usr/bin/env python3
"""
Aggregate rust-code-analysis metrics for all JSON reports in a folder.

Columns produced:
  – Total LOC        (sum of SLOC for every file)
  – Mean CCN         (function‑weighted average cyclomatic complexity)
  – Total CCN        (sum of cyclomatic complexity over all functions)
  – Halstead Volume  (sum of Halstead volume over all functions)
  – Median Diff      (median Halstead difficulty across all functions)
  – 95th Diff        (95‑th percentile Halstead difficulty)
  – Max Diff         (maximum Halstead difficulty)
  – Func Cnt         (number of functions encountered)

The script is dependency‑free (uses only the stdlib).
"""

import argparse
import json
import statistics
from pathlib import Path
from typing import Dict, Any, List


def walk_functions(unit: Dict[str, Any]):
    """Recursively yield every function node (``kind == 'function'``)."""
    if unit.get("kind") == "function":
        yield unit
    for child in unit.get("spaces", []):
        yield from walk_functions(child)


def percentile(values: List[float], pct: float) -> float:
    """Return the *pct*‑percentile (e.g. ``0.95`` for the 95‑th percentile).

    Uses the **nearest‑rank** method, which is simple, deterministic, and
    requires nothing beyond the Python stdlib.
    """
    if not values:
        return 0.0
    if not 0 <= pct <= 1:
        raise ValueError("percentile must be in [0, 1]")

    ordered = sorted(values)
    k = int(round(pct * (len(ordered) - 1)))  # 0‑based index
    return float(ordered[k])


def collect_project_metrics(folder: Path):
    """Aggregate metrics from every ``*.json`` report in *folder*."""

    total_loc = 0
    total_cc = 0
    total_volume = 0.0
    difficulties: List[float] = []
    func_cnt = 0

    for report in folder.glob("*.json"):
        with report.open(encoding="utf‑8") as fh:
            data = json.load(fh)

        # A report can be either a dict (single file) or a list (multi‑file)
        file_units = data if isinstance(data, list) else [data]

        for file_unit in file_units:
            # ---------- file‑level SLOC ----------
            sloc = file_unit.get("metrics", {}).get("loc", {}).get("lloc", 0)
            total_loc += sloc

            # ---------- function‑level metrics ----------
            for fn in walk_functions(file_unit):
                m = fn.get("metrics", {})
                cyclo = m.get("cyclomatic", {})
                hals = m.get("halstead", {})

                total_cc += cyclo.get("sum", 0)
                total_volume += hals.get("volume", 0.0)

                diff = hals.get("difficulty")
                if diff is not None:
                    difficulties.append(diff)

                func_cnt += 1

    # ----------- derived values -----------
    mean_cc = total_cc / func_cnt if func_cnt else 0.0
    median_diff = statistics.median(difficulties) if difficulties else 0.0
    perc95_diff = percentile(difficulties, 0.95)
    max_diff = max(difficulties) if difficulties else 0.0

    return {
        "Total LOC": total_loc,
        "Mean CCN": mean_cc,
        "Total CCN": total_cc,
        "Halstead Volume": total_volume,
        "Median Diff": median_diff,
        "95th Diff": perc95_diff,
        "Func Cnt": func_cnt,
    }


def main():
    parser = argparse.ArgumentParser(
        description="Aggregate rust‑code‑analysis JSON reports in a folder"
    )
    parser.add_argument(
        "folder", type=Path, help="Folder containing *.json metric reports"
    )
    args = parser.parse_args()

    stats = collect_project_metrics(args.folder)

    print("\nAggregated metrics for", args.folder.resolve())
    print("-----------------------------------------------------------")
    print(f"Total LOC        : {stats['Total LOC']}")
    print(f"Mean CCN         : {stats['Mean CCN']:.2f}")
    print(f"Total CCN        : {stats['Total CCN']}")
    print(f"Halstead Volume  : {stats['Halstead Volume']:.2f}")
    print(f"Median Diff      : {stats['Median Diff']:.2f}")
    print(f"95th Diff        : {stats['95th Diff']:.2f}")
    print(f"Func Cnt         : {stats['Func Cnt']}")
    print("-----------------------------------------------------------\n")


if __name__ == "__main__":
    main()
