#!/usr/bin/env python3
"""
cccccc_metrics.py – extract project‑level numbers from a CCCCC HTML report

Metrics printed
---------------
• Total LOCpro
• Mean Cyclomatic Complexity
• Total Cyclomatic Complexity
• Total Halstead Volume
• Median Halstead Difficulty
• 95th‑percentile Halstead Difficulty
• Number of functions
• Average CallCount

Usage
-----
    python ccccc_metrics.py path/to/out.html

Requirements
------------
    pip install pandas lxml
"""
import sys
import pandas as pd

# ---- column labels in the CCCCC HTML table -------------------------------
COL = {
    "loc"        : "LOCpro",
    "cc"         : "MVG",
    "volume"     : "Volume",
    "difficulty" : "Difficulty",
    "fanout"     : "CallCount",
}

def main(html_path: str) -> None:
    """Parse *html_path* and print summary metrics."""

    # Read the first (and only) table produced by CCCCC
    df = pd.read_html(html_path)[0]

    # Ensure numeric dtype, coercing non‑numeric cells to NaN
    df[[*COL.values()]] = df[[*COL.values()]].apply(pd.to_numeric, errors="coerce")

    total_loc    = int(df[COL["loc"]].sum())
    total_cc     = int(df[COL["cc"]].sum())
    mean_cc      = round(df[COL["cc"]].mean(), 2)
    total_vol    = round(df[COL["volume" ]].sum(), 2)
    median_diff  = round(df[COL["difficulty"]].median(), 2)
    perc95_diff  = round(df[COL["difficulty"]].quantile(0.95), 2)
    func_count   = len(df)
    avg_call_cnt = round(df[COL["fanout"]].mean(), 2)

    print(f"{'Total LOCpro:':28} {total_loc}")
    print(f"{'Mean Cyclomatic Complexity:':28} {mean_cc}")
    print(f"{'Total Cyclomatic Complexity:':28} {total_cc}")
    print(f"{'Total Halstead Volume:':28} {total_vol}")
    print(f"{'Median Halstead Difficulty:':28} {median_diff}")
    print(f"{'95th‑percentile Difficulty:':28} {perc95_diff}")
    print(f"{'Number of functions:':28} {func_count}")
    print(f"{'Average CallCount:':28} {avg_call_cnt}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Usage: python ccccc_metrics.py out.html")
    main(sys.argv[1])
